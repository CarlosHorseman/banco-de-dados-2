create schema pratica5;
use pratica5;

create table dados_multimidia (
código int primary key,
nome varchar (30),
tipo varchar (20),
dados longblob);

insert into dados_multimidia (código,nome,tipo,dados) values
(1,'teste1','jpg',load_file("E:\Pictures\1.jpg")),
(2,'teste2','png',load_file("E:\Pictures\01.png")),
(3,'teste3','png',load_file("‪E:\Pictures\3.png")); 

select dados into outfile 'E:\Pictures\1.jpg'
from dados_multimidia
where código = 1;

select dados into outfile 'E:\Pictures\01.png'
from dados_multimidia
where código = 2;

select dados into outfile '‪E:\Pictures\3.png'
from dados_multimidia
where código = 3;

select * from dados_multimidia; 

